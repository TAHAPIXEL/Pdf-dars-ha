/**
 * Builds a single self-contained HTML file (public/riazi-quest.html) from the
 * standalone template, injecting the REAL curriculum data straight from
 * src/lib/curriculum/*.ts so the content is 100% identical to the app.
 */
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const ids = ["ch1", "ch2", "ch3", "ch4", "ch5", "ch6", "ch7", "ch8", "ch9"];

const chapters = ids.map((id) => {
  const file = path.join(root, "src/lib/curriculum", `${id}.ts`);
  let src = fs.readFileSync(file, "utf8");
  // strip the type import and the TS annotation around the export
  src = src.replace(/import type[^\n]*\n/, "");
  src = src.replace(new RegExp(`export const ${id}: Chapter =`), `const ${id} =`);
  // the remaining body is plain JS object literal data
  const fn = new Function(`${src}; return ${id};`);
  return fn();
});

const template = fs.readFileSync(path.join(root, "standalone/template.html"), "utf8");
const json = JSON.stringify(chapters).replace(/</g, "\\u003c");
const out = template.replace("__CHAPTERS_JSON__", json);

fs.mkdirSync(path.join(root, "public"), { recursive: true });
fs.writeFileSync(path.join(root, "public/riazi-quest.html"), out, "utf8");

const lessons = chapters.reduce((s, c) => s + c.lessons.length, 0);
const questions = chapters.reduce((s, c) => s + c.lessons.reduce((a, l) => a + l.quiz.length, 0) + c.exam.length, 0);
console.log(`OK public/riazi-quest.html  chapters=${chapters.length} lessons=${lessons} questions=${questions} bytes=${out.length}`);
