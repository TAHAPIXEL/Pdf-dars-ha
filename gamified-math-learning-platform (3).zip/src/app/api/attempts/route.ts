import { db } from "@/db";
import { attempts } from "@/db/schema";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

/** POST /api/attempts -> record a quiz/exam attempt */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const kind = body.kind === "exam" ? "exam" : "quiz";
    const ref = String(body.ref ?? "").slice(0, 40);
    const correct = Math.max(0, Number(body.correct) || 0);
    const total = Math.max(1, Number(body.total) || 1);
    const score20 = Math.max(0, Math.min(20, Math.round((correct / total) * 20)));
    if (!ref) return Response.json({ ok: false }, { status: 400 });
    await db.insert(attempts).values({
      playerId: body.playerId ? String(body.playerId) : null,
      kind,
      ref,
      correct,
      total,
      score20,
    });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
