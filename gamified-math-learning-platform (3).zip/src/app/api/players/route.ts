import { db } from "@/db";
import { players } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

/** GET /api/players -> top 20 players by XP */
export async function GET() {
  try {
    const top = await db
      .select()
      .from(players)
      .orderBy(desc(players.xp), desc(players.updatedAt))
      .limit(20);
    return Response.json({ ok: true, players: top });
  } catch (e) {
    return Response.json({ ok: false, players: [] }, { status: 500 });
  }
}

/** POST /api/players -> upsert a player's score */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const id = String(body.id ?? "");
    const name = String(body.name ?? "").trim().slice(0, 40);
    const xp = Math.max(0, Math.min(1000000, Number(body.xp) || 0));
    const streak = Math.max(0, Math.min(10000, Number(body.streak) || 0));
    if (!id || !name) {
      return Response.json({ ok: false, error: "bad payload" }, { status: 400 });
    }
    await db
      .insert(players)
      .values({ id, name, xp, streak, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: players.id,
        set: { name, xp: sql`GREATEST(${players.xp}, ${xp})`, streak, updatedAt: new Date() },
      });
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ ok: false }, { status: 500 });
  }
}
