import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { chapters, getChapter } from "@/lib/curriculum";
import ExamView from "@/components/ExamView";

export function generateStaticParams() {
  return chapters.map((c) => ({ chapter: c.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ chapter: string }> }): Promise<Metadata> {
  const { chapter } = await params;
  const c = getChapter(chapter);
  return { title: c ? `آزمون پایان ${c.title} | ریاضی‌کوئست` : "ریاضی‌کوئست" };
}

export default async function ExamPage({ params }: { params: Promise<{ chapter: string }> }) {
  const { chapter: slug } = await params;
  const chapter = getChapter(slug);
  if (!chapter) notFound();
  return <ExamView chapter={chapter} />;
}
