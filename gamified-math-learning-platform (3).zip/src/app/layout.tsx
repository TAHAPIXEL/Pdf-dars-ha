import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import "./globals.css";

export const metadata: Metadata = {
  title: "ریاضی‌کوئست | ریاضی نهم را مثل یک بازی یاد بگیر",
  description:
    "کل کتاب ریاضی پایهٔ نهم با آموزش قدم‌به‌قدم، کوییزهای چالشی با افکت صوتی، گرافیک سه‌بعدی، سیستم XP و لول، و آزمون پایان هر فصل — کاملاً رایگان و فارسی.",
  keywords: ["ریاضی نهم", "آموزش ریاضی", "کوییز", "پایه نهم", "ریاضی"],
};

export const viewport: Viewport = {
  themeColor: "#05080f",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-ink text-snow antialiased bg-fabric">
        <Navbar />
        <main className="pt-20 min-h-[calc(100vh-80px)]">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
