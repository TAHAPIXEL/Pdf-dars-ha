import type { Metadata } from "next";
import { db } from "@/db";
import { players } from "@/db/schema";
import { desc } from "drizzle-orm";
import LeaderboardList from "@/components/LeaderboardList";
import { Trophy } from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "تابلوی قهرمانان | ریاضی‌کوئست",
  description: "رتبه‌بندی قهرمانان ریاضی‌کوئست بر اساس XP",
};

export default async function LeaderboardPage() {
  let rows: { id: string; name: string; xp: number; streak: number }[] = [];
  try {
    rows = await db.select().from(players).orderBy(desc(players.xp), desc(players.updatedAt)).limit(20);
  } catch {
    rows = [];
  }

  return (
    <div className="mx-auto max-w-2xl px-4 sm:px-6 py-10">
      <header className="text-center mb-10">
        <div className="w-20 h-20 mx-auto rounded-3xl grid place-items-center bg-gradient-to-br from-xp to-amberr rotate-3 mb-5 shadow-[0_0_50px_-10px_rgba(250,204,21,.6)]">
          <Trophy className="w-10 h-10 text-ink" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-black mb-3">تابلوی قهرمانان</h1>
        <p className="text-fog leading-8">
          ۲۰ قهرمان برتر ریاضی‌کوئست — درس‌ها را تمام کن، کوییز و آزمون بده و XP جمع کن تا اسم‌ت این‌جا بدرخشد.
        </p>
      </header>
      <LeaderboardList rows={rows} />
    </div>
  );
}
