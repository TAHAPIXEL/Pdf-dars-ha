import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { chapters, getLesson } from "@/lib/curriculum";
import LessonView from "@/components/LessonView";

export function generateStaticParams() {
  return chapters.flatMap((c) => c.lessons.map((l) => ({ chapter: c.slug, lesson: l.slug })));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ chapter: string; lesson: string }>;
}): Promise<Metadata> {
  const { chapter, lesson } = await params;
  const data = getLesson(chapter, lesson);
  return { title: data ? `${data.lesson.title} | ریاضی‌کوئست` : "ریاضی‌کوئست" };
}

export default async function LessonPage({
  params,
}: {
  params: Promise<{ chapter: string; lesson: string }>;
}) {
  const { chapter, lesson } = await params;
  const data = getLesson(chapter, lesson);
  if (!data) notFound();
  return <LessonView chapter={data.chapter} lesson={data.lesson} prev={data.prev} next={data.next} />;
}
