import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { chapters, getChapter } from "@/lib/curriculum";
import ChapterPath from "@/components/ChapterPath";
import ChapterIcon from "@/components/ChapterIcon";
import { BadgeCheck } from "lucide-react";
import { toFa } from "@/lib/utils";

export function generateStaticParams() {
  return chapters.map((c) => ({ chapter: c.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ chapter: string }> }): Promise<Metadata> {
  const { chapter: slug } = await params;
  const c = getChapter(slug);
  return { title: c ? `${c.title} | ریاضی‌کوئست` : "ریاضی‌کوئست" };
}

export default async function ChapterPage({ params }: { params: Promise<{ chapter: string }> }) {
  const { chapter: slug } = await params;
  const chapter = getChapter(slug);
  if (!chapter) notFound();

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-10">
      {/* hero */}
      <header className="glass rounded-3xl p-7 sm:p-10 relative overflow-hidden mb-4">
        <div
          className="absolute -top-28 -right-28 w-80 h-80 rounded-full blur-[110px] opacity-35 pointer-events-none"
          style={{ background: chapter.color }}
        />
        <div className="absolute -bottom-28 -left-28 w-72 h-72 rounded-full blur-[110px] opacity-20 pointer-events-none bg-violet" />
        <div className="relative flex flex-wrap items-start gap-6">
          <div
            className="w-20 h-20 sm:w-24 sm:h-24 rounded-[26px] grid place-items-center rotate-3 shrink-0"
            style={{ background: `${chapter.color}22`, border: `1px solid ${chapter.color}66` }}
          >
            <ChapterIcon icon={chapter.icon} className="w-10 h-10 sm:w-12 sm:h-12" />
          </div>
          <div className="flex-1 min-w-60">
            <div className="text-xs font-black mb-2 tracking-wide" style={{ color: chapter.color }}>
              سرزمین شمارهٔ {toFa(chapter.id)}
            </div>
            <h1 className="text-2xl sm:text-4xl font-black leading-[1.5] mb-3">{chapter.title}</h1>
            <p className="text-fog leading-8">{chapter.subtitle}</p>
          </div>
        </div>
        <div className="relative mt-7">
          <div className="text-sm font-black text-fog mb-3">در این سرزمین یاد می‌گیری:</div>
          <div className="flex flex-wrap gap-2.5">
            {chapter.outcomes.map((o) => (
              <span
                key={o}
                className="inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold bg-white/[0.05] border border-white/10"
              >
                <BadgeCheck className="w-3.5 h-3.5" style={{ color: chapter.color }} />
                {o}
              </span>
            ))}
          </div>
        </div>
      </header>

      <div className="text-center mt-10">
        <h2 className="text-xl font-black text-fog">
          مسیر فصل را دنبال کن — از بالا تا <span style={{ color: chapter.color }}>جام قهرمانی</span> پایین نقشه
        </h2>
      </div>

      <ChapterPath chapter={chapter} />
    </div>
  );
}
