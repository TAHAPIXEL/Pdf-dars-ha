"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Flame, Map, Medal, Play, Sparkles, Star, Trophy, Zap } from "lucide-react";
import { chapters } from "@/lib/curriculum";
import ChapterIcon from "@/components/ChapterIcon";
import TiltCard from "@/components/TiltCard";
import { useGame, levelFor, XP_PER_LEVEL } from "@/lib/store";
import { sfx } from "@/lib/sounds";
import { toFa } from "@/lib/utils";

function Ring({ pct, color, size = 56 }: { pct: number; color: string; size?: number }) {
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(148,163,184,.15)" strokeWidth="6" fill="none" />
      <motion.circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        stroke={color}
        strokeWidth="6"
        fill="none"
        strokeLinecap="round"
        strokeDasharray={c}
        initial={{ strokeDashoffset: c }}
        animate={{ strokeDashoffset: c - (c * pct) / 100 }}
        transition={{ duration: 1, ease: "easeOut" }}
      />
    </svg>
  );
}

export default function LearnPage() {
  const { xp, streak, completedLessons, examResults, lessonResults } = useGame();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const lv = levelFor(xp);

  const totalDone = mounted ? completedLessons.length : 0;
  const examsPassed = mounted ? Object.keys(examResults).length : 0;

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-10">
      {/* header HUD */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-6 sm:p-8 mb-10 relative overflow-hidden">
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full blur-[100px] bg-violet/25 pointer-events-none" />
        <div className="relative flex flex-wrap items-center gap-6">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Ring pct={lv.pct} color="#a78bfa" size={76} />
              <div className="absolute inset-0 grid place-items-center">
                <span className="text-xl font-black text-violet">{toFa(lv.level)}</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 font-black text-lg">
                <Map className="w-5 h-5 text-violet" /> نقشهٔ فصل‌ها
              </div>
              <div className="text-sm text-fog mt-1">
                {toFa(xp)} XP — {toFa(XP_PER_LEVEL - lv.into)} XP تا لول {toFa(lv.level + 1)}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3 mr-auto">
            <span className="glass rounded-xl px-4 py-2 text-sm font-black flex items-center gap-1.5 text-orangey">
              <Flame className="w-4 h-4" /> {toFa(streak)} روز استریک
            </span>
            <span className="glass rounded-xl px-4 py-2 text-sm font-black flex items-center gap-1.5 text-skyy">
              <Play className="w-4 h-4" /> {toFa(totalDone)} درس تمام‌شده
            </span>
            <span className="glass rounded-xl px-4 py-2 text-sm font-black flex items-center gap-1.5 text-xp">
              <Trophy className="w-4 h-4" /> {toFa(examsPassed)} آزمون
            </span>
          </div>
        </div>
        {/* xp bar */}
        <div className="relative mt-5 h-2 rounded-full bg-white/5 overflow-hidden">
          <motion.div
            className="h-full rounded-full bg-gradient-to-l from-violet to-skyy"
            initial={{ width: 0 }}
            animate={{ width: `${lv.pct}%` }}
            transition={{ duration: 1, delay: 0.3 }}
          />
        </div>
      </motion.div>

      <h1 className="text-3xl sm:text-4xl font-black mb-2">
        ۹ سرزمین <span className="text-grad">ماجراجویی</span>
      </h1>
      <p className="text-fog mb-10 leading-8">
        هر فصل را همان‌طور که در کتاب است دنبال کن: درس‌ها را بخوان، کوییزشان را بگذران و در آخر جام قهرمانی فصل را بردار!
      </p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {chapters.map((c, i) => {
          const doneCount = mounted ? c.lessons.filter((l) => completedLessons.includes(l.slug)).length : 0;
          const pct = Math.round((doneCount / c.lessons.length) * 100);
          const exam = mounted ? examResults[c.slug] : undefined;
          const starsTotal = mounted
            ? c.lessons.reduce((s, l) => s + (lessonResults[l.slug]?.stars ?? 0), 0)
            : 0;
          const status = exam ? "کامل شد" : doneCount > 0 ? "در حال ماجراجویی" : "آمادهٔ شروع";
          return (
            <motion.div
              key={c.slug}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: (i % 3) * 0.08 }}
            >
              <Link href={`/learn/${c.slug}`} onClick={() => sfx.pop()} onMouseEnter={() => sfx.hover()}>
                <TiltCard className="glass rounded-3xl p-6 h-full relative overflow-hidden group hover:border-white/25 transition-all">
                  <div
                    className="absolute -top-16 -left-16 w-44 h-44 rounded-full blur-[70px] opacity-25 group-hover:opacity-45 transition-opacity pointer-events-none"
                    style={{ background: c.color }}
                  />
                  <div className="relative">
                    <div className="flex items-start justify-between mb-5">
                      <div
                        className="w-14 h-14 rounded-2xl grid place-items-center rotate-3 group-hover:rotate-6 transition-transform"
                        style={{ background: `${c.color}22`, border: `1px solid ${c.color}55` }}
                      >
                        <ChapterIcon icon={c.icon} className="w-7 h-7" />
                      </div>
                      {exam ? (
                        <span className="flex items-center gap-1.5 rounded-xl bg-xp/15 border border-xp/30 px-3 py-1.5 text-xs font-black text-xp">
                          <Medal className="w-3.5 h-3.5" /> نمره {toFa(exam.score20)}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 rounded-xl bg-white/5 border border-white/10 px-3 py-1.5 text-xs font-bold text-fog">
                          <Star className="w-3.5 h-3.5 text-xp fill-xp" /> {toFa(starsTotal)} ستاره
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-black mb-1" style={{ color: c.color }}>
                      فصل {toFa(c.id)}
                    </div>
                    <h3 className="font-black text-lg mb-1.5">{c.title.split(":")[1]?.trim()}</h3>
                    <p className="text-fog text-xs leading-6 mb-5">{c.subtitle}</p>

                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-2.5 rounded-full bg-white/5 border border-white/10 overflow-hidden">
                        <motion.div
                          className="h-full rounded-full"
                          style={{ background: c.color }}
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ duration: 0.8, delay: 0.2 }}
                        />
                      </div>
                      <span className="text-xs font-black text-fog whitespace-nowrap">
                        {toFa(doneCount)}/{toFa(c.lessons.length)} درس
                      </span>
                    </div>
                    <div className="mt-4 flex items-center justify-between text-xs font-bold">
                      <span className={exam ? "text-xp" : "text-fog"}>{status}</span>
                      <span className="flex items-center gap-1" style={{ color: c.color }}>
                        ورود به سرزمین <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
                      </span>
                    </div>
                  </div>
                </TiltCard>
              </Link>
            </motion.div>
          );
        })}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="mt-12 glass rounded-3xl p-6 sm:p-8 text-center"
      >
        <Sparkles className="w-8 h-8 mx-auto text-xp mb-3" />
        <h3 className="font-black text-xl mb-2">شورشِ نمرهٔ ۲۰ از کجا شروع می‌شود؟</h3>
        <p className="text-fog text-sm leading-7 max-w-xl mx-auto">
          از فصل اول، «مجموعه‌ها». هر درس فقط چند دقیقه طول می‌کشد؛ ولی XP، ستاره و اعتمادبه‌نفست برای همیشه می‌ماند.
        </p>
      </motion.div>
    </div>
  );
}
