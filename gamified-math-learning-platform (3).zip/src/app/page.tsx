"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  BadgeCheck,
  Crown,
  Flame,
  Gamepad2,
  Heart,
  Layers,
  Play,
  Rocket,
  Sparkles,
  Star,
  Trophy,
  Volume2,
  Zap,
} from "lucide-react";
import { chapters, totalLessons, totalQuestions } from "@/lib/curriculum";
import { Inline } from "@/components/MathText";
import ChapterIcon from "@/components/ChapterIcon";
import TiltCard from "@/components/TiltCard";
import Onboarding from "@/components/Onboarding";
import { sfx } from "@/lib/sounds";
import { burst } from "@/components/confetti";
import { toFa } from "@/lib/utils";
import { useGame, levelFor } from "@/lib/store";

const Hero3D = dynamic(() => import("@/components/Hero3D"), { ssr: false });

/* ---------- live demo mini-question ---------- */
const DEMO_Q = {
  q: "حاصل `2^3 × 2^2` کدام است؟",
  options: ["`2^6`", "`2^5`", "`4^5`", "`2^1`"],
  answer: 1,
  explain: "در ضرب هم‌پایه‌ها توان‌ها جمع می‌شوند: `2^(3+2) = 2^5`.",
};

function DemoQuestion() {
  const [picked, setPicked] = useState<number | null>(null);
  return (
    <div className="glass rounded-3xl p-6 sm:p-8 max-w-xl mx-auto">
      <div className="flex items-center gap-2 mb-4 text-sm font-black text-mint">
        <Gamepad2 className="w-4 h-4" /> همین حالا تستش کن!
      </div>
      <p className="font-black text-lg leading-9 mb-5">
        <Inline text={DEMO_Q.q} />
      </p>
      <div className="grid grid-cols-2 gap-3">
        {DEMO_Q.options.map((o, i) => {
          const chosen = picked === i;
          const isRight = i === DEMO_Q.answer;
          return (
            <button
              key={i}
              disabled={picked !== null}
              onClick={() => {
                setPicked(i);
                if (isRight) {
                  sfx.correct();
                  burst({ y: 0.75 });
                } else {
                  sfx.wrong();
                }
              }}
              className={`rounded-2xl border-2 px-4 py-3.5 font-black transition-all cursor-pointer ${
                picked === null
                  ? "border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:-translate-y-0.5"
                  : isRight
                  ? "border-mint bg-mint/15 text-mint animate-pop"
                  : chosen
                  ? "border-rosee bg-rosee/15 text-rosee animate-shake"
                  : "border-white/5 opacity-40"
              }`}
            >
              <Inline text={o} />
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-4 text-sm leading-7 text-fog">
          <Inline text={DEMO_Q.explain} />
          <span className="block mt-2 text-violet font-bold">دیدی؟ همین‌جور کوییز، صدا و افکت توی همهٔ ۳۳ درس هست.</span>
        </motion.div>
      )}
    </div>
  );
}

/* ---------- leaderboard teaser ---------- */
interface PlayerRow {
  id: string;
  name: string;
  xp: number;
  streak: number;
}

function LeaderboardTeaser() {
  const [rows, setRows] = useState<PlayerRow[]>([]);
  useEffect(() => {
    fetch("/api/players")
      .then((r) => r.json())
      .then((d) => setRows(Array.isArray(d.players) ? d.players.slice(0, 5) : []))
      .catch(() => setRows([]));
  }, []);
  if (rows.length === 0) return null;
  return (
    <div className="glass rounded-3xl p-6 max-w-xl mx-auto">
      <div className="flex items-center gap-2 mb-4 text-sm font-black text-xp">
        <Trophy className="w-4 h-4" /> قهرمانان فعلی
      </div>
      <div className="space-y-2.5">
        {rows.map((p, i) => (
          <div key={p.id} className="flex items-center gap-3 rounded-xl bg-white/[0.04] px-4 py-2.5">
            <span className={`w-7 h-7 grid place-items-center rounded-lg text-xs font-black ${i === 0 ? "bg-xp text-ink" : i === 1 ? "bg-slate-300 text-ink" : i === 2 ? "bg-amber-700 text-ink" : "bg-white/10 text-fog"}`}>
              {toFa(i + 1)}
            </span>
            <span className="flex-1 font-bold text-sm truncate">{p.name}</span>
            <span className="flex items-center gap-1 text-xp font-black text-sm">
              <Zap className="w-3.5 h-3.5" /> {toFa(p.xp)}
            </span>
          </div>
        ))}
      </div>
      <Link href="/leaderboard" onClick={() => sfx.click()} className="mt-4 flex items-center justify-center gap-2 text-sm font-bold text-violet hover:text-snow transition-colors">
        تابلوی کامل قهرمانان <ArrowLeft className="w-4 h-4" />
      </Link>
    </div>
  );
}

/* ---------- landing ---------- */
const FEATURES = [
  { icon: Gamepad2, title: "بازی‌گونه، نه کلاس‌گونه", text: "کوییز با قلب و ستاره، XP، لول، دشمنِ نمرهٔ بد و تاجِ آزمون پایان فصل.", color: "#a78bfa" },
  { icon: Volume2, title: "افکت صوتی برای همه‌چیز", text: "هر کلیک، هر جواب درست و غلط و هر لول‌آپ صدای خودش را دارد؛ همه با Web Audio ساخته می‌شود.", color: "#22d3ee" },
  { icon: Layers, title: "گرافیک سه‌بعدی زنده", text: "اشکال هندسی شناور با نورپردازی واقعی؛ می‌توانی با موس بچرخانی‌شان.", color: "#34d399" },
  { icon: Sparkles, title: "آموزش قدم‌به‌قدم", text: "مثال‌ها را خودت قدم‌به‌قدم باز می‌کنی؛ نکته‌های طلایی ته هر درس منتظرت است.", color: "#fbbf24" },
  { icon: Trophy, title: "کوییز و آزمون با نمره", text: "آخر هر درس کوییز، آخر هر فصل آزمون ۱۰ سؤالی با نمره از ۲۰.", color: "#fb7185" },
  { icon: Flame, title: "استریک و تابلوی قهرمانان", text: "هر روز سر بزن تا شعله‌ات خاموش نشود و اسم‌ت را در جدول ببین.", color: "#fb923c" },
];

export default function Landing() {
  const router = useRouter();
  const { xp, streak } = useGame();
  const [mounted, setMounted] = useState(false);
  const [onboardOpen, setOnboardOpen] = useState(false);
  const playerName = useGame((s) => s.playerName);
  useEffect(() => setMounted(true), []);
  const lv = levelFor(xp);

  const startQuest = () => {
    sfx.levelup();
    if (playerName) router.push("/learn");
    else setOnboardOpen(true);
  };

  return (
    <div className="relative">
      <Onboarding open={onboardOpen} onClose={() => setOnboardOpen(false)} />

      {/* ================= HERO ================= */}
      <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden">
        <Hero3D />
        <div className="absolute inset-0 bg-grid -z-20" />
        <div className="relative z-10 text-center px-4 pt-10 pb-24 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 glass rounded-full px-5 py-2 text-sm font-bold text-fog mb-7"
          >
            <Sparkles className="w-4 h-4 text-xp" />
            کل کتاب ریاضی نهم — از صفر تا صد، فارسی و رایگان
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-6xl lg:text-7xl font-black leading-[1.35] sm:leading-[1.3]"
          >
            ریاضی نهم را
            <br />
            <span className="text-grad">مثل یک بازی</span> فتح کن
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 text-fog text-base sm:text-lg leading-9 max-w-2xl mx-auto"
          >
            {toFa(9)} فصل، {toFa(totalLessons)} درس تعاملی و بیش از {toFa(totalQuestions)} سوال چالشی؛ با صدای
            برد، کانفتی، قلب و ستاره، آزمون پایان فصل و تابلوی قهرمانان. ریاضی حالا دیگر ترسناک نیست — اعتیادآور است!
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-9 flex flex-wrap items-center justify-center gap-4"
          >
            <button
              onClick={startQuest}
              onMouseEnter={() => sfx.hover()}
              className="btn3d rounded-2xl px-9 py-4 text-lg font-black text-ink bg-gradient-to-l from-violet to-skyy cursor-pointer flex items-center gap-2"
            >
              <Rocket className="w-5 h-5" />
              شروع ماجراجویی
            </button>
            <Link
              href="/learn"
              onClick={() => sfx.whoosh()}
              onMouseEnter={() => sfx.hover()}
              className="btn3d rounded-2xl px-9 py-4 text-lg font-black border border-white/15 bg-white/5 cursor-pointer flex items-center gap-2"
            >
              <Play className="w-5 h-5" />
              دیدن نقشهٔ فصل‌ها
            </Link>
          </motion.div>

          {/* floating chips */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.55 }}
            className="mt-12 flex flex-wrap items-center justify-center gap-3 text-sm font-black"
          >
            <span className="glass rounded-full px-4 py-2 text-xp flex items-center gap-1.5 animate-floaty">
              <Zap className="w-4 h-4" /> +۵۰ XP برای هر درس
            </span>
            <span className="glass rounded-full px-4 py-2 text-rosee flex items-center gap-1.5 animate-floaty" style={{ animationDelay: "0.4s" }}>
              <Heart className="w-4 h-4 fill-rosee" /> ۳ قلب در هر کوییز
            </span>
            <span className="glass rounded-full px-4 py-2 text-orangey flex items-center gap-1.5 animate-floaty" style={{ animationDelay: "0.8s" }}>
              <Flame className="w-4 h-4" /> استریک روزانه
            </span>
            {mounted && xp > 0 && (
              <span className="glass rounded-full px-4 py-2 text-mint flex items-center gap-1.5 animate-floaty" style={{ animationDelay: "1.1s" }}>
                <BadgeCheck className="w-4 h-4" /> تو الان لول {toFa(lv.level)} هستی!
              </span>
            )}
          </motion.div>
        </div>
      </section>

      {/* ================= STATS ================= */}
      <section className="relative py-8">
        <div className="mx-auto max-w-5xl px-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { icon: Layers, n: 9, label: "فصل کامل", c: "#a78bfa" },
            { icon: Gamepad2, n: totalLessons, label: "درس تعاملی", c: "#22d3ee" },
            { icon: Trophy, n: totalQuestions, label: "سوال با پاسخ تشریحی", c: "#fbbf24" },
            { icon: Crown, n: 9, label: "آزمون پایان فصل", c: "#fb7185" },
          ].map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
            >
              <TiltCard className="glass rounded-3xl p-6 text-center">
                <s.icon className="w-7 h-7 mx-auto mb-3" style={{ color: s.c }} />
                <div className="text-3xl font-black" style={{ color: s.c }}>
                  {toFa(s.n)}+
                </div>
                <div className="text-sm text-fog mt-1 font-bold">{s.label}</div>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ================= DEMO ================= */}
      <section className="py-16 px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-black mb-3">یک سوال، همین‌جا!</h2>
          <p className="text-fog">بدون ثبت‌نام، بدون صبر؛ زبان این سایت را بچش</p>
        </motion.div>
        <DemoQuestion />
      </section>

      {/* ================= FEATURES ================= */}
      <section className="py-14 px-4">
        <div className="mx-auto max-w-6xl">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-black mb-3">
              چرا <span className="text-grad">ریاضی‌کوئست</span>؟
            </h2>
            <p className="text-fog">هر ابزاری که مغز عاشقش است، این‌جاست</p>
          </motion.div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
              >
                <TiltCard className="glass rounded-3xl p-7 h-full">
                  <div
                    className="w-12 h-12 rounded-2xl grid place-items-center mb-4 rotate-3"
                    style={{ background: `${f.color}20`, border: `1px solid ${f.color}44` }}
                  >
                    <f.icon className="w-6 h-6" style={{ color: f.color }} />
                  </div>
                  <h3 className="font-black text-lg mb-2">{f.title}</h3>
                  <p className="text-fog text-sm leading-7">{f.text}</p>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= CHAPTERS SHOWCASE ================= */}
      <section className="py-16 px-4">
        <div className="mx-auto max-w-6xl">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-black mb-3">۹ سرزمین برای فتح کردن</h2>
            <p className="text-fog">هر فصل یک دنیا با رنگ و شخصیت خودش است</p>
          </motion.div>
          <div className="flex gap-4 overflow-x-auto pb-6 snap-x snap-mandatory sm:grid sm:grid-cols-3 sm:overflow-visible">
            {chapters.map((c, i) => (
              <motion.div
                key={c.slug}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: Math.min(i * 0.05, 0.4) }}
                className="snap-center shrink-0 w-64 sm:w-auto"
              >
                <Link href={`/learn/${c.slug}`} onClick={() => sfx.pop()} onMouseEnter={() => sfx.hover()}>
                  <TiltCard className="glass rounded-3xl p-6 h-full group hover:border-white/25 transition-colors">
                    <div
                      className="w-12 h-12 rounded-2xl grid place-items-center mb-4 -rotate-6 group-hover:rotate-3 transition-transform"
                      style={{ background: `${c.color}22`, border: `1px solid ${c.color}55` }}
                    >
                      <ChapterIcon icon={c.icon} className="w-6 h-6" />
                    </div>
                    <div className="text-xs font-black mb-1" style={{ color: c.color }}>
                      فصل {toFa(c.id)}
                    </div>
                    <h3 className="font-black">{c.title.split(":")[1]?.trim()}</h3>
                    <p className="text-fog text-xs leading-6 mt-2">{c.subtitle}</p>
                    <div className="mt-4 flex items-center gap-1 text-xs font-bold text-fog">
                      {toFa(c.lessons.length)} درس + آزمون
                      <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
                    </div>
                  </TiltCard>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= LEADERBOARD TEASER ================= */}
      <section className="py-10 px-4">
        <LeaderboardTeaser />
      </section>

      {/* ================= FINAL CTA ================= */}
      <section className="py-20 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="mx-auto max-w-4xl glass rounded-[36px] p-10 sm:p-14 text-center relative overflow-hidden"
        >
          <div className="absolute inset-0 opacity-30 pointer-events-none" style={{ background: "radial-gradient(70% 100% at 50% 0%, rgba(167,139,250,.5), transparent)" }} />
          <div className="relative">
            <Star className="w-12 h-12 mx-auto mb-5 text-xp fill-xp animate-floaty" />
            <h2 className="text-3xl sm:text-5xl font-black leading-[1.4] mb-4">
              اولین کوئستت
              <br />
              یک کلیک با تو فاصله دارد
            </h2>
            <p className="text-fog leading-8 mb-8 max-w-xl mx-auto">
              از «مجموعه‌ها» شروع کن؛ کمتر از ۱۵ دقیقه طول می‌کشد و قول می‌دهیم تهش حس کنندهٔ ریاضی نمی‌گیری، حس قهرمان می‌گیری.
            </p>
            <button
              onClick={startQuest}
              onMouseEnter={() => sfx.hover()}
              className="btn3d rounded-2xl px-10 py-4 text-lg font-black text-ink bg-gradient-to-l from-mint to-skyy cursor-pointer inline-flex items-center gap-2"
            >
              <Rocket className="w-5 h-5" /> بزن بریم — مجانی!
              {mounted && streak > 0 && <span className="text-xs">(استریک فعلی: {toFa(streak)} روز)</span>}
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
