import { Box, Braces, ChartColumn, Compass, Divide, Infinity, Shapes, TrendingUp, Zap } from "lucide-react";
import type { Chapter } from "@/lib/curriculum";

const MAP = {
  shapes: Shapes,
  infinity: Infinity,
  compass: Compass,
  zap: Zap,
  braces: Braces,
  trending: TrendingUp,
  divide: Divide,
  box: Box,
  chart: ChartColumn,
} as const;

export default function ChapterIcon({ icon, className }: { icon: Chapter["icon"]; className?: string }) {
  const C = MAP[icon];
  return <C className={className} />;
}
