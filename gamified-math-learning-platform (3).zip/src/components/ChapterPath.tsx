"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Check, Lock, Play, Star, Trophy } from "lucide-react";
import type { Chapter } from "@/lib/curriculum";
import { useGame } from "@/lib/store";
import { sfx } from "@/lib/sounds";
import { toFa } from "@/lib/utils";

const OFFSETS = [0, 52, 0, -52];

export default function ChapterPath({ chapter }: { chapter: Chapter }) {
  const router = useRouter();
  const { completedLessons, lessonResults, examResults } = useGame();
  const [mounted, setMounted] = useState(false);
  const [shaking, setShaking] = useState<string | null>(null);
  useEffect(() => setMounted(true), []);

  const isDone = (slug: string) => mounted && completedLessons.includes(slug);
  const isUnlocked = (i: number) => !mounted || i === 0 || completedLessons.includes(chapter.lessons[i - 1].slug);
  const examOpen = mounted && chapter.lessons.every((l) => completedLessons.includes(l.slug));
  const examRes = mounted ? examResults[chapter.slug] : undefined;

  const deny = (key: string) => {
    sfx.wrong();
    setShaking(key);
    setTimeout(() => setShaking(null), 500);
  };

  const nodes = [
    ...chapter.lessons.map((l, i) => ({ type: "lesson" as const, data: l, i })),
    { type: "exam" as const, data: null, i: chapter.lessons.length },
  ];

  return (
    <div className="relative py-10">
      {/* dashed spine */}
      <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-px">
        <svg className="w-8 h-full -translate-x-1/2" aria-hidden>
          <line x1="50%" y1="0" x2="50%" y2="100%" stroke="rgba(148,163,184,.3)" strokeWidth="3" strokeDasharray="6 10" className="path-dash" />
        </svg>
      </div>

      <div className="relative flex flex-col items-center gap-14 py-4">
        {nodes.map((node) => {
          const offset = OFFSETS[node.i % 4];
          if (node.type === "lesson") {
            const l = node.data!;
            const done = isDone(l.slug);
            const unlocked = isUnlocked(node.i);
            const res = mounted ? lessonResults[l.slug] : undefined;
            const key = l.slug;
            const content = (
              <div className="flex flex-col items-center gap-3">
                <div
                  className={`w-[72px] h-[72px] rounded-full grid place-items-center border-4 transition-all ${
                    shaking === key ? "animate-shake" : ""
                  } ${
                    done
                      ? "bg-mint border-mint/40 shadow-[0_0_30px_-4px_rgba(52,211,153,.6)]"
                      : unlocked
                      ? "animate-pulse-ring"
                      : "bg-panel2 border-white/10"
                  }`}
                  style={
                    !done && unlocked
                      ? { background: chapter.color, borderColor: "rgba(255,255,255,.3)" }
                      : undefined
                  }
                >
                  {done ? (
                    <Check className="w-8 h-8 text-ink" strokeWidth={3} />
                  ) : unlocked ? (
                    <Play className="w-8 h-8 text-ink fill-ink" />
                  ) : (
                    <Lock className="w-7 h-7 text-fog" />
                  )}
                </div>
                <div className="glass rounded-2xl px-4 py-3 text-center max-w-52">
                  <div className="text-[11px] font-black" style={{ color: chapter.color }}>
                    درس {toFa(node.i + 1)}
                  </div>
                  <div className="text-sm font-bold leading-6">{l.title}</div>
                  {done && res && (
                    <div className="mt-1 flex items-center justify-center gap-1 text-xs text-xp">
                      {Array.from({ length: 3 }).map((_, s) => (
                        <Star
                          key={s}
                          className={`w-3.5 h-3.5 ${s < res.stars ? "fill-xp" : "text-line"}`}
                        />
                      ))}
                      <span className="text-fog mr-1">+{toFa(res.correct * 10 + 25)} XP</span>
                    </div>
                  )}
                  {!unlocked && <div className="text-[11px] text-fog mt-1">ابتدا درس قبل را تمام کن</div>}
                </div>
              </div>
            );

            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                style={{ transform: `translateX(${offset}px)` }}
              >
                {unlocked ? (
                  <Link
                    href={`/learn/${chapter.slug}/${l.slug}`}
                    onClick={() => sfx.pop()}
                    onMouseEnter={() => sfx.hover()}
                    className="block hover:scale-105 transition-transform"
                  >
                    {content}
                  </Link>
                ) : (
                  <button onClick={() => deny(key)} className="cursor-not-allowed">
                    {content}
                  </button>
                )}
              </motion.div>
            );
          }

          // exam node
          const examNode = (
            <div className="flex flex-col items-center gap-3">
              <div
                className={`w-24 h-24 rounded-[28px] grid place-items-center border-4 rotate-3 ${
                  shaking === "exam" ? "animate-shake" : ""
                } ${
                  examRes
                    ? "bg-xp border-xp/50 shadow-[0_0_40px_-4px_rgba(250,204,21,.6)]"
                    : examOpen
                    ? "bg-gradient-to-br from-violet to-pinky border-white/30 animate-pulse-ring"
                    : "bg-panel2 border-white/10"
                }`}
              >
                <Trophy className={`w-10 h-10 ${examRes || examOpen ? "text-ink" : "text-fog"}`} />
              </div>
              <div className="glass rounded-2xl px-5 py-3 text-center max-w-56">
                <div className="text-[11px] font-black text-xp">آزمون پایان فصل</div>
                <div className="text-sm font-bold">۱۰ سوال — نمره از ۲۰</div>
                {examRes ? (
                  <div className="mt-1 text-xs font-black text-xp">نمره: {toFa(examRes.score20)} از ۲۰</div>
                ) : !examOpen ? (
                  <div className="text-[11px] text-fog mt-1">اول همهٔ درس‌ها را تمام کن</div>
                ) : (
                  <div className="text-[11px] text-mint font-bold mt-1">باز است! برو بگیرش</div>
                )}
              </div>
            </div>
          );

          return (
            <motion.div
              key="exam"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              style={{ transform: `translateX(${OFFSETS[(node.i) % 4]}px)` }}
            >
              {examOpen ? (
                <button onClick={() => { sfx.unlock(); router.push(`/exam/${chapter.slug}`); }} className="hover:scale-105 transition-transform cursor-pointer">
                  {examNode}
                </button>
              ) : (
                <button onClick={() => deny("exam")} className="cursor-not-allowed">
                  {examNode}
                </button>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
