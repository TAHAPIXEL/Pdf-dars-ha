"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, ShieldAlert, Trophy } from "lucide-react";
import type { Chapter } from "@/lib/curriculum";
import QuizEngine, { type QuizOutcome } from "@/components/QuizEngine";
import { useGame } from "@/lib/store";
import { sfx } from "@/lib/sounds";
import { toFa } from "@/lib/utils";

export default function ExamView({ chapter }: { chapter: Chapter }) {
  const recordExam = useGame((s) => s.recordExam);
  const completedLessons = useGame((s) => s.completedLessons);
  const examResults = useGame((s) => s.examResults);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
    sfx.whoosh();
  }, []);

  const doneCount = mounted ? chapter.lessons.filter((l) => completedLessons.includes(l.slug)).length : 0;
  const allDone = doneCount === chapter.lessons.length;
  const prevRes = mounted ? examResults[chapter.slug] : undefined;

  const onFinish = (o: QuizOutcome) => recordExam(chapter.slug, o);

  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 py-10">
      <motion.div initial={{ opacity: 0, y: -14 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <Link
          href={`/learn/${chapter.slug}`}
          onClick={() => sfx.click()}
          className="inline-flex items-center gap-2 text-sm font-bold text-fog hover:text-snow"
        >
          <ArrowRight className="w-4 h-4" /> برگشت به {chapter.title}
        </Link>
      </motion.div>

      <motion.header
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-3xl p-7 sm:p-9 mb-8 relative overflow-hidden"
      >
        <div
          className="absolute -top-24 -left-24 w-72 h-72 rounded-full blur-[100px] opacity-30 pointer-events-none"
          style={{ background: chapter.color }}
        />
        <div className="relative">
          <div className="flex items-center gap-3 mb-3">
            <span className="w-12 h-12 rounded-2xl grid place-items-center bg-xp/20 border border-xp/30 -rotate-6">
              <Trophy className="w-6 h-6 text-xp" />
            </span>
            <div>
              <div className="text-xs font-black" style={{ color: chapter.color }}>
                نبرد بزرگ
              </div>
              <h1 className="text-xl sm:text-2xl font-black">آزمون پایان {chapter.title}</h1>
            </div>
          </div>
          <p className="text-fog leading-8 text-[15px]">
            {toFa(chapter.exam.length)} سوال از کل فصل. نمرهٔ نهایی‌ات از ۲۰ محاسبه می‌شود و در تابلوی قهرمانان اثر می‌گذارد.
            {prevRes && (
              <span className="text-xp font-bold">
                {" "}
                بهترین نمرهٔ فعلی تو: {toFa(prevRes.score20)} از ۲۰.
              </span>
            )}
          </p>
          {!allDone && (
            <div className="mt-5 rounded-2xl border border-amberr/30 bg-amberr/10 px-4 py-3 flex items-center gap-3 text-sm leading-7 text-amberr">
              <ShieldAlert className="w-5 h-5 shrink-0" />
              هنوز {toFa(chapter.lessons.length - doneCount)} درس از این فصل را تمام نکرده‌ای؛ می‌توانی آزمون بدهی ولی پیشنهاد ما این است اول درس‌ها را بگذرانی!
            </div>
          )}
        </div>
      </motion.header>

      <QuizEngine
        key={chapter.slug}
        questions={chapter.exam}
        accent="#facc15"
        mode="exam"
        title={`آزمون پایان ${chapter.title}`}
        onFinish={onFinish}
      />
    </div>
  );
}
