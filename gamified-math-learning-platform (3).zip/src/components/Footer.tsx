import { GraduationCap, Heart } from "lucide-react";
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="relative mt-24 border-t border-white/10 bg-abyss/60">
      <div className="mx-auto max-w-7xl px-5 py-12 grid gap-10 sm:grid-cols-3">
        <div>
          <div className="flex items-center gap-2.5 mb-4">
            <span className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-violet to-skyy">
              <GraduationCap className="w-5 h-5 text-ink" />
            </span>
            <span className="font-black text-lg">ریاضی‌کوئست</span>
          </div>
          <p className="text-fog text-sm leading-7">
            کل کتاب ریاضی نهم، از مجموعه‌ها تا آمار، قدم‌به‌قدم، با کوییزهای چالشی، افکت‌های صوتی و
            گرافیک سه‌بعدی — مثل یک بازی، نه یک کلاس خسته‌کننده.
          </p>
        </div>
        <div>
          <h4 className="font-black mb-4">دسترسی سریع</h4>
          <ul className="space-y-2.5 text-sm text-fog">
            <li><Link href="/learn" className="hover:text-snow transition-colors">نقشهٔ ۹ فصل</Link></li>
            <li><Link href="/leaderboard" className="hover:text-snow transition-colors">تابلوی قهرمانان</Link></li>
            <li><Link href="/learn/sets" className="hover:text-snow transition-colors">شروع از فصل اول</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-black mb-4">قوانین کوئست</h4>
          <ul className="space-y-2.5 text-sm text-fog leading-7">
            <li>هر درس: بخوان + کوییز بده + XP جمع کن</li>
            <li>آخر هر فصل: آزمون ۱۰ سؤالی با نمره از ۲۰</li>
            <li>هر روز سر بزن تا شعلهٔ استریک روشن بماند</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5 py-5 text-center text-xs text-fog">
        ساخته‌شده با <Heart className="w-3.5 h-3.5 inline text-rosee fill-rosee" /> برای دانش‌آموزان پایهٔ نهم — ریاضی‌کوئست ۱۴۰۴
      </div>
    </footer>
  );
}
