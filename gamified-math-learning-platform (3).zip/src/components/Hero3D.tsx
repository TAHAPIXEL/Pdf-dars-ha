"use client";

import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Sparkles, MeshDistortMaterial } from "@react-three/drei";
import * as THREE from "three";

function Shapes() {
  const group = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (!group.current) return;
    const { pointer } = state;
    group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, pointer.x * 0.22, 0.05);
    group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, -pointer.y * 0.18, 0.05);
  });

  return (
    <group ref={group}>
      {/* hero torus knot */}
      <Float speed={1.6} rotationIntensity={0.9} floatIntensity={1.4}>
        <mesh position={[0, 0.2, 0]}>
          <torusKnotGeometry args={[1.15, 0.34, 240, 34]} />
          <MeshDistortMaterial
            color="#8b5cf6"
            emissive="#4c1d95"
            emissiveIntensity={0.55}
            roughness={0.18}
            metalness={0.75}
            distort={0.22}
            speed={2.2}
          />
        </mesh>
      </Float>

      {/* emerald icosahedron */}
      <Float speed={2.2} rotationIntensity={1.4} floatIntensity={2}>
        <mesh position={[-3.6, 1.15, -1.6]}>
          <icosahedronGeometry args={[0.72, 0]} />
          <meshStandardMaterial color="#34d399" emissive="#065f46" emissiveIntensity={0.7} roughness={0.25} metalness={0.6} flatShading />
        </mesh>
      </Float>

      {/* cyan ring */}
      <Float speed={1.8} rotationIntensity={1.1} floatIntensity={1.6}>
        <mesh position={[3.7, 1.3, -1.2]} rotation={[Math.PI / 3.2, 0.4, 0.2]}>
          <torusGeometry args={[0.62, 0.2, 22, 60]} />
          <meshStandardMaterial color="#22d3ee" emissive="#155e75" emissiveIntensity={0.8} roughness={0.2} metalness={0.7} />
        </mesh>
      </Float>

      {/* amber octahedron */}
      <Float speed={2.6} rotationIntensity={1.6} floatIntensity={2.2}>
        <mesh position={[-2.7, -1.6, -0.6]}>
          <octahedronGeometry args={[0.5, 0]} />
          <meshStandardMaterial color="#fbbf24" emissive="#92400e" emissiveIntensity={0.7} roughness={0.25} metalness={0.7} flatShading />
        </mesh>
      </Float>

      {/* pink cone */}
      <Float speed={2.1} rotationIntensity={1.2} floatIntensity={1.8}>
        <mesh position={[2.8, -1.7, -0.4]} rotation={[0.3, 0.8, 0.1]}>
          <coneGeometry args={[0.48, 0.95, 5]} />
          <meshStandardMaterial color="#f472b6" emissive="#9d174d" emissiveIntensity={0.65} roughness={0.3} metalness={0.5} flatShading />
        </mesh>
      </Float>

      {/* tiny indigo cubes - scattered like "dice of numbers" */}
      {[
        [-4.6, -0.4, -2.6],
        [4.8, -0.3, -2.8],
        [1.8, 2.3, -3.2],
        [-1.6, 2.6, -3.6],
      ].map((p, i) => (
        <Float key={i} speed={2 + i * 0.35} rotationIntensity={2} floatIntensity={2.4}>
          <mesh position={p as [number, number, number]}>
            <boxGeometry args={[0.34, 0.34, 0.34]} />
            <meshStandardMaterial color="#818cf8" emissive="#312e81" emissiveIntensity={0.85} roughness={0.3} metalness={0.6} />
          </mesh>
        </Float>
      ))}

      <Sparkles count={110} scale={[13, 8, 6]} size={2.6} speed={0.5} color="#a5b4fc" opacity={0.7} />
    </group>
  );
}

export default function Hero3D() {
  return (
    <div className="absolute inset-0 -z-10">
      <Canvas
        dpr={[1, 1.8]}
        camera={{ position: [0, 0, 8], fov: 52 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={0.55} />
        <directionalLight position={[6, 8, 5]} intensity={1.6} />
        <pointLight position={[-6, -4, 2]} intensity={18} color="#22d3ee" />
        <pointLight position={[6, 4, 2]} intensity={18} color="#a78bfa" />
        <Suspense fallback={null}>
          <Shapes />
        </Suspense>
      </Canvas>
      {/* soft fade into page */}
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink to-transparent pointer-events-none" />
    </div>
  );
}
