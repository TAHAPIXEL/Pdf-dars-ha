"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Crown, Flame, Medal, User, Zap } from "lucide-react";
import { useGame } from "@/lib/store";
import { toFa } from "@/lib/utils";

interface Row {
  id: string;
  name: string;
  xp: number;
  streak: number;
}

function RankBadge({ rank }: { rank: number }) {
  if (rank === 1)
    return (
      <span className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-xp to-amberr text-ink">
        <Crown className="w-5 h-5" />
      </span>
    );
  if (rank === 2)
    return (
      <span className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-slate-200 to-slate-400 text-ink font-black text-sm">
        {toFa(rank)}
      </span>
    );
  if (rank === 3)
    return (
      <span className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-amber-600 to-amber-800 text-ink font-black text-sm">
        {toFa(rank)}
      </span>
    );
  return (
    <span className="w-9 h-9 rounded-xl grid place-items-center bg-white/5 border border-white/10 text-fog font-black text-sm">
      {toFa(rank)}
    </span>
  );
}

export default function LeaderboardList({ rows }: { rows: Row[] }) {
  const playerId = useGame((s) => s.playerId);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (rows.length === 0) {
    return (
      <div className="glass rounded-3xl p-10 text-center">
        <Medal className="w-12 h-12 mx-auto text-fog mb-4" />
        <h3 className="font-black text-xl mb-2">هنوز هیچ قهرمانی نیست!</h3>
        <p className="text-fog text-sm leading-7">
          اولین نفری باش که اسمش را این‌جا حک می‌کند؛ از صفحهٔ اصلی ثبت‌نام کن و XP جمع کن.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {rows.map((p, i) => {
        const isMe = mounted && playerId === p.id;
        return (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className={`glass rounded-2xl px-5 py-4 flex items-center gap-4 ${
              isMe ? "!border-violet shadow-[0_0_40px_-10px_rgba(167,139,250,.5)]" : ""
            }`}
          >
            <RankBadge rank={i + 1} />
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <span className="w-10 h-10 rounded-xl grid place-items-center bg-white/5 border border-white/10 shrink-0">
                <User className="w-5 h-5 text-fog" />
              </span>
              <div className="min-w-0">
                <div className="font-black truncate">
                  {p.name}
                  {isMe && <span className="text-violet text-xs font-bold"> (تو!)</span>}
                </div>
                <div className="text-xs text-fog flex items-center gap-1 mt-0.5">
                  <Flame className="w-3 h-3 text-orangey" /> استریک {toFa(p.streak)} روز
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 text-xp font-black shrink-0">
              <Zap className="w-4 h-4" />
              {toFa(p.xp)}
              <span className="text-[10px] text-fog font-bold hidden sm:inline">XP</span>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
