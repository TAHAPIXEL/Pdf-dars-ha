"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  BookOpenCheck,
  ChevronDown,
  GraduationCap,
  Lightbulb,
  MousePointerClick,
  Trophy,
} from "lucide-react";
import type { Chapter, Lesson, LessonSection } from "@/lib/curriculum";
import { Inline } from "@/components/MathText";
import QuizEngine, { type QuizOutcome } from "@/components/QuizEngine";
import { useGame } from "@/lib/store";
import { sfx } from "@/lib/sounds";
import { starPop } from "@/components/confetti";
import { toFa } from "@/lib/utils";

/** Example whose steps are revealed one by one, like a game. */
function StepReveal({ example, accent }: { example: NonNullable<LessonSection["example"]>; accent: string }) {
  const [shown, setShown] = useState(0);
  const total = example.steps.length;
  const done = shown >= total;

  const reveal = () => {
    if (done) return;
    const next = shown + 1;
    setShown(next);
    if (next === total) {
      sfx.coin();
      starPop();
    } else {
      sfx.pop();
    }
  };

  return (
    <div className="mt-5 rounded-2xl border border-white/10 bg-black/30 overflow-hidden">
      <div className="px-5 py-3 border-b border-white/10 flex items-center gap-2 text-sm font-black text-skyy">
        <MousePointerClick className="w-4 h-4" />
        مثال تعاملی — قدم‌ها را خودت باز کن!
      </div>
      <div className="p-5">
        <p className="font-bold leading-8 mb-4">
          <Inline text={example.problem} />
        </p>
        <div className="space-y-2.5">
          {example.steps.slice(0, shown).map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: 20, scale: 0.97 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              className="flex items-start gap-3 rounded-xl bg-white/[0.04] border border-white/5 px-4 py-3 text-[15px] leading-7"
            >
              <span
                className="shrink-0 w-6 h-6 rounded-lg grid place-items-center text-[11px] font-black text-ink mt-0.5"
                style={{ background: accent }}
              >
                {toFa(i + 1)}
              </span>
              <Inline text={s} />
            </motion.div>
          ))}
        </div>
        {!done ? (
          <button
            onClick={reveal}
            onMouseEnter={() => sfx.hover()}
            className="btn3d mt-4 rounded-xl px-6 py-2.5 text-sm font-black text-ink cursor-pointer flex items-center gap-2"
            style={{ background: accent }}
          >
            {shown === 0 ? "شروع حل قدم‌به‌قدم" : "قدم بعدی"}
            <ChevronDown className="w-4 h-4" />
          </button>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 rounded-xl px-4 py-3 font-black text-mint bg-mint/10 border border-mint/25 flex items-center gap-2"
          >
            <BookOpenCheck className="w-5 h-5" />
            <Inline text={`پاسخ نهایی: ${example.answer}`} className="!font-black" />
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default function LessonView({
  chapter,
  lesson,
  prev,
  next,
}: {
  chapter: Chapter;
  lesson: Lesson;
  prev: Lesson | null;
  next: Lesson | null;
}) {
  const recordLesson = useGame((s) => s.recordLesson);
  const completedLessons = useGame((s) => s.completedLessons);
  const [quizDone, setQuizDone] = useState(false);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
    sfx.whoosh();
  }, []);

  const allDone = mounted && chapter.lessons.every((l) => completedLessons.includes(l.slug));
  const already = mounted && completedLessons.includes(lesson.slug);

  const onFinish = (o: QuizOutcome) => {
    recordLesson(lesson.slug, o);
    setQuizDone(true);
  };

  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 py-10">
      {/* breadcrumb */}
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 text-sm text-fog mb-6">
        <Link href="/learn" onClick={() => sfx.click()} className="hover:text-snow flex items-center gap-1">
          <GraduationCap className="w-4 h-4" /> نقشه
        </Link>
        <span>/</span>
        <Link href={`/learn/${chapter.slug}`} onClick={() => sfx.click()} className="hover:text-snow" style={{ color: chapter.color }}>
          {chapter.title.replace("فصل ", "ف.").split(":")[0]}
        </Link>
        <span>/</span>
        <span className="text-snow font-bold">درس {toFa(lesson.slug)}</span>
      </motion.div>

      {/* header */}
      <motion.header
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-3xl p-7 sm:p-9 mb-10 relative overflow-hidden"
      >
        <div
          className="absolute -top-24 -left-24 w-72 h-72 rounded-full blur-[90px] opacity-30 pointer-events-none"
          style={{ background: chapter.color }}
        />
        <div className="relative">
          <span
            className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-black text-ink mb-4"
            style={{ background: chapter.color }}
          >
            {chapter.title}
          </span>
          <h1 className="text-2xl sm:text-4xl font-black leading-[1.5] mb-3">{lesson.title}</h1>
          <p className="text-fog leading-8">{lesson.intro}</p>
          {already && (
            <div className="mt-4 inline-flex items-center gap-2 rounded-xl bg-mint/10 border border-mint/25 px-4 py-2 text-sm font-bold text-mint">
              <BookOpenCheck className="w-4 h-4" /> این درس را قبلاً با موفقیت تمام کرده‌ای!
            </div>
          )}
        </div>
      </motion.header>

      {/* sections timeline */}
      <div className="relative">
        <div className="absolute right-[27px] top-2 bottom-2 w-px bg-white/10 hidden sm:block" />
        <div className="space-y-8">
          {lesson.sections.map((sec, i) => (
            <motion.section
              key={i}
              initial={{ opacity: 0, y: 34 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.45 }}
              className="sm:pr-16 relative"
            >
              <div
                className="hidden sm:grid absolute right-0 top-0 w-14 h-14 rounded-2xl place-items-center text-xl font-black text-ink rotate-3"
                style={{ background: chapter.color }}
              >
                {toFa(i + 1)}
              </div>
              <div className="glass rounded-3xl p-6 sm:p-8">
                <h2 className="text-xl sm:text-2xl font-black mb-4 flex items-center gap-3">
                  <span
                    className="sm:hidden inline-grid w-9 h-9 rounded-xl place-items-center text-base font-black text-ink shrink-0"
                    style={{ background: chapter.color }}
                  >
                    {toFa(i + 1)}
                  </span>
                  {sec.heading}
                </h2>
                <p className="text-justify leading-9 text-[15.5px] text-snow/90">
                  <Inline text={sec.body} />
                </p>
                {sec.example && <StepReveal example={sec.example} accent={chapter.color} />}
              </div>
            </motion.section>
          ))}
        </div>
      </div>

      {/* golden tip */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="mt-10 rounded-3xl border border-xp/30 bg-gradient-to-l from-xp/15 to-amberr/5 p-6 sm:p-7 flex gap-4 items-start"
      >
        <div className="w-12 h-12 rounded-2xl bg-xp/20 grid place-items-center shrink-0 -rotate-6">
          <Lightbulb className="w-6 h-6 text-xp" />
        </div>
        <div>
          <div className="font-black text-xp mb-1.5">نکتهٔ طلایی</div>
          <p className="leading-8 text-[15px]">
            <Inline text={lesson.tip} />
          </p>
        </div>
      </motion.div>

      {/* quiz */}
      <div id="quiz" className="mt-14 scroll-mt-24">
        <h2 className="text-2xl font-black mb-6 flex items-center gap-3">
          <span className="w-10 h-10 rounded-xl grid place-items-center" style={{ background: `${chapter.color}26`, color: chapter.color }}>
            <Trophy className="w-5 h-5" />
          </span>
          کوییز پایان درس
        </h2>
        <QuizEngine
          key={lesson.slug}
          questions={lesson.quiz}
          accent={chapter.color}
          mode="lesson"
          title={`کوییز: ${lesson.title}`}
          onFinish={onFinish}
        />
      </div>

      {/* next navigation */}
      {(quizDone || already) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-10 grid sm:grid-cols-2 gap-4"
        >
          {prev ? (
            <Link
              href={`/learn/${chapter.slug}/${prev.slug}`}
              onClick={() => sfx.whoosh()}
              className="glass rounded-2xl p-5 flex items-center gap-3 hover:bg-white/[0.06] transition-colors group"
            >
              <ArrowRight className="w-5 h-5 text-fog group-hover:text-snow" />
              <div>
                <div className="text-xs text-fog">درس قبلی</div>
                <div className="font-bold text-sm mt-0.5">{prev.title}</div>
              </div>
            </Link>
          ) : (
            <div className="hidden sm:block" />
          )}
          {next ? (
            <Link
              href={`/learn/${chapter.slug}/${next.slug}`}
              onClick={() => sfx.unlock()}
              className="btn3d rounded-2xl p-5 flex items-center gap-3 text-ink justify-start"
              style={{ background: chapter.color }}
            >
              <div className="flex-1">
                <div className="text-xs opacity-70 font-bold">درس بعدی باز شد!</div>
                <div className="font-black mt-0.5">{next.title}</div>
              </div>
              <ArrowLeft className="w-5 h-5" />
            </Link>
          ) : allDone ? (
            <Link
              href={`/exam/${chapter.slug}`}
              onClick={() => sfx.levelup()}
              className="btn3d rounded-2xl p-5 flex items-center gap-3 text-ink justify-start bg-xp"
            >
              <div className="flex-1">
                <div className="text-xs opacity-70 font-bold">همهٔ درس‌ها تمام شد!</div>
                <div className="font-black mt-0.5">برو سراغ آزمون پایان فصل</div>
              </div>
              <Trophy className="w-5 h-5" />
            </Link>
          ) : (
            <Link
              href={`/learn/${chapter.slug}`}
              onClick={() => sfx.click()}
              className="btn3d rounded-2xl p-5 flex items-center gap-3 text-ink justify-start"
              style={{ background: chapter.color }}
            >
              <div className="flex-1">
                <div className="text-xs opacity-70 font-bold">این آخرین درس بود</div>
                <div className="font-black mt-0.5">برگرد به نقشهٔ فصل</div>
              </div>
              <ArrowLeft className="w-5 h-5" />
            </Link>
          )}
        </motion.div>
      )}
    </div>
  );
}
