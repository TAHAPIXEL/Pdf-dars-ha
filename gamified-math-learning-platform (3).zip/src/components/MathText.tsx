import { Fragment, type ReactNode } from "react";
import { toFa } from "@/lib/utils";

/**
 * Mini math renderer.
 * - Inside math segments, ASCII digits become Persian digits.
 * - `^2` or `^(a+b)` renders as superscript.
 * - Math is rendered in an LTR span so expressions keep natural order.
 *
 * Authoring contract: wrap inline math in backticks inside normal text,
 * e.g. "مقدار `x = ۳` را داریم" via <Inline text="..." />.
 */

let uidCounter = 0;

function renderCore(src: string, prefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  let buf = "";
  let key = 0;
  const flush = () => {
    if (buf) {
      nodes.push(<Fragment key={`${prefix}-${key++}`}>{toFa(buf)}</Fragment>);
      buf = "";
    }
  };
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (ch === "^" && i + 1 < src.length) {
      flush();
      if (src[i + 1] === "(") {
        const close = src.indexOf(")", i + 2);
        const inner = close === -1 ? src.slice(i + 2) : src.slice(i + 2, close);
        nodes.push(
          <sup key={`${prefix}-${key++}`} className="text-[0.72em] font-semibold">
            {renderCore(inner, `${prefix}s${i}`)}
          </sup>
        );
        i = close === -1 ? src.length : close;
      } else {
        nodes.push(
          <sup key={`${prefix}-${key++}`} className="text-[0.72em] font-semibold">
            {toFa(src[i + 1])}
          </sup>
        );
        i++;
      }
    } else {
      buf += ch;
    }
  }
  flush();
  return nodes;
}

/** Raw math expression rendered LTR with Persian digits. */
export function M({ children, className }: { children: string; className?: string }) {
  return (
    <span dir="ltr" className={`math-inline ${className ?? ""}`}>
      {renderCore(children, `m${(uidCounter = (uidCounter + 1) % 100000)}`)}
    </span>
  );
}

/** Mixed Persian text + backticked inline math expressions. */
export function Inline({ text, className }: { text: string; className?: string }) {
  const parts = text.split("`");
  return (
    <span className={className}>
      {parts.map((p, i) =>
        i % 2 === 1 ? <M key={i}>{p}</M> : <Fragment key={i}>{toFa(p)}</Fragment>
      )}
    </span>
  );
}

/** Big centered display math block. */
export function MathBlock({ children, className }: { children: string; className?: string }) {
  return (
    <div
      dir="ltr"
      className={`rounded-xl bg-black/30 border border-white/10 px-4 py-3 text-center text-lg sm:text-xl font-semibold tracking-wide text-snow ${className ?? ""}`}
    >
      {renderCore(children, `b${(uidCounter = (uidCounter + 1) % 100000)}`)}
    </div>
  );
}
