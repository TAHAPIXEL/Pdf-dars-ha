"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Flame, GraduationCap, Map, Trophy, Volume2, VolumeX, Zap, Menu, X } from "lucide-react";
import { useGame, levelFor } from "@/lib/store";
import { toFa } from "@/lib/utils";
import { sfx } from "@/lib/sounds";

const LINKS = [
  { href: "/", label: "خانه" },
  { href: "/learn", label: "نقشهٔ فصل‌ها", icon: Map },
  { href: "/leaderboard", label: "تابلوی قهرمانان", icon: Trophy },
];

export default function Navbar() {
  const pathname = usePathname();
  const { xp, streak, muted, toggleMuted, playerName } = useGame();
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => setMounted(true), []);

  const lv = levelFor(xp);

  return (
    <header className="fixed top-0 inset-x-0 z-50">
      <div className="mx-auto max-w-7xl px-3 sm:px-5">
        <div className="glass-strong rounded-2xl mt-3 px-3 sm:px-4 h-14 flex items-center justify-between gap-2">
          <Link
            href="/"
            onClick={() => sfx.click()}
            className="flex items-center gap-2.5 shrink-0"
          >
            <span className="w-9 h-9 rounded-xl grid place-items-center bg-gradient-to-br from-violet to-skyy shadow-[0_0_18px_rgba(167,139,250,.45)]">
              <GraduationCap className="w-5 h-5 text-ink" />
            </span>
            <span className="font-black text-lg hidden sm:inline">ریاضی‌کوئست</span>
          </Link>

          <nav className="hidden md:flex items-center gap-7">
            {LINKS.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                onClick={() => sfx.hover()}
                data-active={pathname === l.href}
                className="navlink text-sm font-bold text-fog hover:text-snow transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {mounted && (
              <>
                <div className="hidden sm:flex items-center gap-1.5 rounded-xl bg-xp/10 border border-xp/25 px-2.5 py-1.5 text-sm font-black text-xp">
                  <Zap className="w-4 h-4" />
                  {toFa(lv.level)} <span className="text-[10px] font-bold text-fog">لول</span>
                </div>
                <div className="flex items-center gap-1.5 rounded-xl bg-orangey/10 border border-orangey/25 px-2.5 py-1.5 text-sm font-black text-orangey">
                  <Flame className="w-4 h-4" />
                  {toFa(streak)}
                  <span className="text-[10px] font-bold text-fog hidden sm:inline">روز</span>
                </div>
                {playerName && (
                  <div className="hidden lg:block max-w-28 truncate text-xs font-bold text-fog px-1">
                    {playerName}
                  </div>
                )}
              </>
            )}
            <button
              onClick={() => {
                toggleMuted();
                setTimeout(() => sfx.click(), 10);
              }}
              className="w-9 h-9 rounded-xl border border-white/10 bg-white/5 grid place-items-center text-fog hover:text-snow hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="سوییچ صدا"
            >
              {mounted && muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setOpen(!open)}
              className="md:hidden w-9 h-9 rounded-xl border border-white/10 bg-white/5 grid place-items-center text-fog cursor-pointer"
              aria-label="منو"
            >
              {open ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {open && (
            <motion.nav
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="md:hidden glass-strong rounded-2xl mt-2 p-3 flex flex-col gap-1"
            >
              {LINKS.map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  onClick={() => {
                    sfx.click();
                    setOpen(false);
                  }}
                  className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold transition-colors ${
                    pathname === l.href ? "bg-white/10 text-snow" : "text-fog hover:bg-white/5"
                  }`}
                >
                  {l.icon ? <l.icon className="w-4 h-4" /> : null}
                  {l.label}
                </Link>
              ))}
            </motion.nav>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
