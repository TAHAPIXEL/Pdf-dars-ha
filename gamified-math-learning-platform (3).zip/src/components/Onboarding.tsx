"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Rocket, User, X } from "lucide-react";
import { useGame } from "@/lib/store";
import { sfx } from "@/lib/sounds";
import { bigWin } from "@/components/confetti";

export default function Onboarding({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [name, setName] = useState("");
  const setPlayer = useGame((s) => s.setPlayer);
  const touchStreak = useGame((s) => s.touchStreak);
  const router = useRouter();

  const submit = () => {
    const n = name.trim();
    if (n.length < 2) return;
    setPlayer(n);
    touchStreak();
    bigWin();
    sfx.win();
    onClose();
    router.push("/learn");
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] grid place-items-center bg-ink/80 backdrop-blur-md px-4"
        >
          <motion.div
            initial={{ scale: 0.85, y: 40 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            transition={{ type: "spring", stiffness: 200, damping: 22 }}
            className="glass-strong rounded-3xl p-8 w-full max-w-md relative"
          >
            <button
              onClick={() => {
                sfx.click();
                onClose();
              }}
              className="absolute top-4 left-4 w-9 h-9 rounded-xl border border-white/10 grid place-items-center text-fog hover:text-snow cursor-pointer"
              aria-label="بستن"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet to-skyy grid place-items-center mb-5 rotate-3">
              <Rocket className="w-8 h-8 text-ink" />
            </div>
            <h3 className="text-2xl font-black mb-2">قهرمان، اسم خودتو بگو!</h3>
            <p className="text-fog text-sm leading-7 mb-6">
              با یک نام مستعار وارد تابلوی قهرمانان شو؛ XPهایت ذخیره می‌شود و با بقیه مسابقه می‌دهی.
            </p>
            <div className="relative mb-6">
              <User className="w-4 h-4 absolute right-4 top-1/2 -translate-y-1/2 text-fog" />
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit()}
                placeholder="مثلن: اژدهای جبری"
                maxLength={30}
                className="w-full rounded-2xl bg-black/40 border border-white/15 py-4 pr-11 pl-4 font-bold text-snow placeholder:text-fog/50 focus:outline-none focus:border-violet transition-colors"
              />
            </div>
            <button
              onClick={submit}
              disabled={name.trim().length < 2}
              className="btn3d w-full rounded-2xl py-4 font-black text-ink bg-gradient-to-l from-violet to-skyy cursor-pointer disabled:opacity-50"
              onMouseEnter={() => sfx.hover()}
            >
              شروع ماجراجویی
            </button>
            <p className="text-center text-xs text-fog mt-4">بدون این کار هم می‌توانی یاد بگیری؛ ولی اسم توی جدول ثبت نمی‌شود.</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
