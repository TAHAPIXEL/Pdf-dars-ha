"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Brain,
  Check,
  Flag,
  Heart,
  Lightbulb,
  RotateCcw,
  Sparkles,
  Star,
  Swords,
  X,
} from "lucide-react";
import type { QuizQ } from "@/lib/curriculum";
import { Inline } from "@/components/MathText";
import { sfx } from "@/lib/sounds";
import { burst, bigWin, starPop } from "@/components/confetti";
import { starsFor } from "@/lib/store";
import { toFa } from "@/lib/utils";

const LETTERS = ["الف", "ب", "ج", "د"];

export interface QuizOutcome {
  correct: number;
  total: number;
  stars: number;
  score20: number;
}

interface Props {
  questions: QuizQ[];
  accent: string;
  mode: "lesson" | "exam";
  title: string;
  introText?: string;
  onFinish?: (o: QuizOutcome) => void;
  deadText?: string;
}

type Phase = "ready" | "run" | "dead" | "done";

export default function QuizEngine({ questions, accent, mode, title, introText, onFinish, deadText }: Props) {
  const [phase, setPhase] = useState<Phase>("ready");
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [hearts, setHearts] = useState(3);
  const [shake, setShake] = useState(false);
  const [finished, setFinished] = useState<QuizOutcome | null>(null);

  const total = questions.length;
  const current = questions[index];
  const correctSoFar = useMemo(
    () => answers.filter((a, i) => a === questions[i].answer).length,
    [answers, questions]
  );

  const reset = () => {
    setPhase("ready");
    setIndex(0);
    setSelected(null);
    setAnswers([]);
    setHearts(3);
    setFinished(null);
  };

  const start = () => {
    sfx.levelup();
    setPhase("run");
  };

  const choose = (i: number) => {
    if (selected !== null) return;
    setSelected(i);
    const isRight = i === current.answer;
    if (isRight) {
      sfx.correct();
      burst({ y: 0.7 });
    } else {
      sfx.wrong();
      setShake(true);
      setTimeout(() => setShake(false), 500);
      if (mode === "lesson") {
        const h = hearts - 1;
        setHearts(h);
      }
    }
  };

  const next = () => {
    const newAnswers = [...answers, selected!];
    setAnswers(newAnswers);
    // lesson-mode death check
    const wrongCount = newAnswers.filter((a, i) => a !== questions[i].answer).length;
    if (mode === "lesson" && wrongCount >= 3) {
      sfx.lose();
      setPhase("dead");
      return;
    }
    if (index + 1 >= total) {
      const correct = newAnswers.filter((a, i) => a === questions[i].answer).length;
      const outcome: QuizOutcome = {
        correct,
        total,
        stars: starsFor(correct, total),
        score20: Math.round((correct / total) * 20),
      };
      setFinished(outcome);
      setPhase("done");
      if (outcome.stars === 3) {
        sfx.win();
        bigWin();
      } else if (outcome.stars >= 1) {
        sfx.levelup();
        burst();
        setTimeout(() => starPop(), 350);
      } else {
        sfx.lose();
      }
      onFinish?.(outcome);
    } else {
      sfx.whoosh();
      setIndex(index + 1);
      setSelected(null);
    }
  };

  return (
    <div className="w-full">
      <AnimatePresence mode="wait">
        {/* ---------------- READY ---------------- */}
        {phase === "ready" && (
          <motion.div
            key="ready"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass rounded-3xl p-8 sm:p-10 text-center relative overflow-hidden"
          >
            <div
              className="absolute inset-0 opacity-20 pointer-events-none"
              style={{ background: `radial-gradient(60% 80% at 50% 0%, ${accent}, transparent)` }}
            />
            <div
              className="w-20 h-20 mx-auto rounded-3xl grid place-items-center mb-5 rotate-3 animate-floaty"
              style={{ background: `${accent}22`, border: `1px solid ${accent}55` }}
            >
              <Swords className="w-10 h-10" style={{ color: accent }} />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black mb-3">{title}</h2>
            <p className="text-fog leading-8 mb-6 max-w-md mx-auto">
              {introText ??
                (mode === "lesson"
                  ? `با ${toFa(total)} سوال چالشی، یادگیری‌ات را محک بزن. مراقب باش: فقط ۳ قلب داری!`
                  : `آزمون پایان فصل: ${toFa(total)} سوال، نمره از ۲۰. همه‌چیزی که یاد گرفتی را رو کن!`)}
            </p>
            <div className="flex items-center justify-center gap-6 mb-7 text-sm text-fog">
              <span className="flex items-center gap-2">
                <Brain className="w-4 h-4 text-violet" /> {toFa(total)} سوال
              </span>
              {mode === "lesson" ? (
                <span className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-rosee fill-rosee" /> ۳ قلب
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Flag className="w-4 h-4 text-amberr" /> نمره از ۲۰
                </span>
              )}
            </div>
            <button
              onClick={start}
              className="btn3d rounded-2xl px-10 py-4 text-lg font-black text-ink cursor-pointer"
              style={{ background: accent }}
            >
              <span className="inline-flex items-center gap-2">
                بزن بریم! <Swords className="w-5 h-5" />
              </span>
            </button>
          </motion.div>
        )}

        {/* ---------------- RUN ---------------- */}
        {phase === "run" && current && (
          <motion.div
            key={`q-${index}`}
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40 }}
            transition={{ duration: 0.25 }}
          >
            {/* hud row */}
            <div className="flex items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm font-bold text-fog">
                <span style={{ color: accent }}>{toFa(index + 1)}</span>
                <span>/</span>
                <span>{toFa(total)}</span>
              </div>
              {mode === "lesson" ? (
                <div className="flex items-center gap-1">
                  {[0, 1, 2].map((i) => (
                    <Heart
                      key={i}
                      className={`w-5 h-5 transition-all ${
                        i < hearts ? "text-rosee fill-rosee" : "text-line fill-transparent opacity-40"
                      }`}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-sm font-bold text-fog">
                  درست تا الان: <span style={{ color: accent }}>{toFa(correctSoFar)}</span>
                </div>
              )}
            </div>
            {/* progress bar */}
            <div className="h-2.5 rounded-full bg-white/5 border border-white/10 overflow-hidden mb-6">
              <motion.div
                className="h-full rounded-full"
                style={{ background: accent }}
                initial={false}
                animate={{ width: `${((index + (selected !== null ? 1 : 0)) / total) * 100}%` }}
                transition={{ type: "spring", stiffness: 120, damping: 20 }}
              />
            </div>

            <div className={`glass rounded-3xl p-6 sm:p-8 ${shake ? "animate-shake" : ""}`}>
              <h3 className="text-lg sm:text-2xl font-black leading-10 mb-7 min-h-16">
                <Inline text={current.q} />
              </h3>
              <div className="grid gap-3 sm:grid-cols-2">
                {current.options.map((opt, i) => {
                  const isCorrect = i === current.answer;
                  const isChosen = selected === i;
                  let style: React.CSSProperties = {};
                  let cls =
                    "group relative text-right rounded-2xl border-2 px-5 py-4 font-bold leading-8 transition-all duration-200 cursor-pointer select-none";
                  if (selected === null) {
                    cls += " border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:-translate-y-0.5 hover:border-white/25";
                  } else if (isCorrect) {
                    cls += " border-mint bg-mint/15 text-mint animate-pop";
                    style = { boxShadow: "0 0 30px -6px rgba(52,211,153,.5)" };
                  } else if (isChosen) {
                    cls += " border-rosee bg-rosee/15 text-rosee";
                  } else {
                    cls += " border-white/5 bg-white/[0.02] opacity-40 pointer-events-none";
                  }
                  return (
                    <button
                      key={i}
                      disabled={selected !== null}
                      onClick={() => choose(i)}
                      onMouseEnter={() => selected === null && sfx.hover()}
                      className={cls}
                      style={style}
                    >
                      <span className="flex items-center gap-3">
                        <span
                          className="shrink-0 w-8 h-8 rounded-xl grid place-items-center text-xs font-black border border-white/15 bg-black/30"
                          style={isCorrect && selected !== null ? { background: "#34d399", color: "#052e1c" } : {}}
                        >
                          {selected !== null && isCorrect ? (
                            <Check className="w-4 h-4" />
                          ) : selected !== null && isChosen && !isCorrect ? (
                            <X className="w-4 h-4" />
                          ) : (
                            LETTERS[i]
                          )}
                        </span>
                        <Inline text={opt} />
                      </span>
                    </button>
                  );
                })}
              </div>

              <AnimatePresence>
                {selected !== null && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="overflow-hidden"
                  >
                    <div
                      className={`mt-6 rounded-2xl border p-5 flex gap-3 items-start ${
                        selected === current.answer
                          ? "border-mint/30 bg-mint/10"
                          : "border-amberr/30 bg-amberr/10"
                      }`}
                    >
                      <Lightbulb
                        className={`w-5 h-5 mt-0.5 shrink-0 ${
                          selected === current.answer ? "text-mint" : "text-amberr"
                        }`}
                      />
                      <div className="flex-1 leading-8 text-[15px]">
                        <span className="font-black block mb-1">
                          {selected === current.answer ? "آفرین! درست بود" : "جواب درست را نگاه کن؛ این را بلد شو:"}
                        </span>
                        <span className="text-fog">
                          <Inline text={current.explain} />
                        </span>
                      </div>
                    </div>
                    <div className="mt-5 flex justify-end">
                      <button
                        onClick={next}
                        onMouseEnter={() => sfx.hover()}
                        className="btn3d rounded-2xl px-8 py-3.5 font-black text-ink flex items-center gap-2 cursor-pointer"
                        style={{ background: accent }}
                      >
                        {index + 1 >= total ? "دیدن نتیجه" : "سوال بعدی"}
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ---------------- DEAD ---------------- */}
        {phase === "dead" && (
          <motion.div
            key="dead"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-3xl p-10 text-center border-rosee/30"
          >
            <div className="w-20 h-20 mx-auto rounded-3xl bg-rosee/15 border border-rosee/30 grid place-items-center mb-5">
              <Heart className="w-10 h-10 text-rosee" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black mb-3">قلب‌ها تمام شد!</h2>
            <p className="text-fog leading-8 mb-7">
              {deadText ?? "سه‌تا اشتباه کردی ولی هیچ اتفاق بدی نیفتاد؛ قهرمان‌ها از همین‌جاها برمی‌خیزند. درس را یک مرور کن و دوباره بیا!"}
            </p>
            <button
              onClick={reset}
              className="btn3d rounded-2xl px-10 py-4 text-lg font-black text-ink bg-rosee cursor-pointer flex items-center gap-2 mx-auto"
            >
              <RotateCcw className="w-5 h-5" /> تلاش دوباره
            </button>
          </motion.div>
        )}

        {/* ---------------- DONE ---------------- */}
        {phase === "done" && finished && (
          <motion.div
            key="done"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-3xl p-8 sm:p-10 text-center relative overflow-hidden"
          >
            <div
              className="absolute inset-0 opacity-25 pointer-events-none"
              style={{ background: `radial-gradient(60% 80% at 50% 0%, ${accent}, transparent)` }}
            />
            <div className="relative">
              <div className="flex items-center justify-center gap-3 mb-6">
                {[0, 1, 2].map((i) => (
                  <motion.span
                    key={i}
                    initial={{ scale: 0, rotate: -30 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.25 + i * 0.22, type: "spring", stiffness: 260, damping: 12 }}
                  >
                    <Star
                      className={`w-12 h-12 sm:w-14 sm:h-14 ${
                        i < finished.stars
                          ? "text-xp fill-xp drop-shadow-[0_0_18px_rgba(250,204,21,.65)]"
                          : "text-line fill-transparent"
                      }`}
                    />
                  </motion.span>
                ))}
              </div>
              <h2 className="text-2xl sm:text-3xl font-black mb-2">
                {finished.stars === 3
                  ? "افسانه‌ای! نمرهٔ کامل گرفتی"
                  : finished.stars === 2
                  ? "عالی بود! خیلی نزدیکی به قله"
                  : finished.stars === 1
                  ? "خوب بود! با یک مرور فوق‌العاده می‌شوی"
                  : "اتفاق افتاد! دوباره تلاش کن، می‌تونی"}
              </h2>
              <p className="text-fog mb-8">
                {mode === "exam" ? "نمرهٔ آزمون پایان فصل" : "نتیجهٔ کوییز درس"}
              </p>

              <div className="grid sm:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
                <div className="rounded-2xl bg-black/30 border border-white/10 p-5">
                  <div className="text-4xl font-black" style={{ color: accent }}>
                    {toFa(finished.correct)}
                    <span className="text-lg text-fog font-bold"> / {toFa(finished.total)}</span>
                  </div>
                  <div className="text-sm text-fog mt-1">پاسخ درست</div>
                </div>
                <div className="rounded-2xl bg-black/30 border border-white/10 p-5">
                  <div className="text-4xl font-black text-xp">
                    {toFa(finished.score20)}
                    <span className="text-lg text-fog font-bold"> / ۲۰</span>
                  </div>
                  <div className="text-sm text-fog mt-1">نمره از ۲۰</div>
                </div>
                <div className="rounded-2xl bg-black/30 border border-white/10 p-5">
                  <div className="text-4xl font-black text-mint">{toFa(Math.round((finished.correct / finished.total) * 100))}٪</div>
                  <div className="text-sm text-fog mt-1">درصد موفقیت</div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3">
                <button
                  onClick={reset}
                  className="btn3d rounded-2xl px-7 py-3.5 font-black border border-white/15 bg-white/5 cursor-pointer flex items-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" /> تلاش دوباره
                </button>
                <button
                  onClick={() => {
                    sfx.whoosh();
                    window.history.back();
                  }}
                  className="btn3d rounded-2xl px-7 py-3.5 font-black text-ink cursor-pointer flex items-center gap-2"
                  style={{ background: accent }}
                >
                  <Sparkles className="w-4 h-4" /> ادامهٔ ماجراجویی
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
