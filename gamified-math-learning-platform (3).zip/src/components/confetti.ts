"use client";

import confetti from "canvas-confetti";

const COLORS = ["#a78bfa", "#22d3ee", "#34d399", "#fbbf24", "#fb7185", "#f472b6", "#ffffff"];

export function burst(origin?: { x?: number; y?: number }) {
  confetti({
    particleCount: 130,
    spread: 80,
    startVelocity: 42,
    origin: { y: 0.65, ...origin },
    colors: COLORS,
    disableForReducedMotion: true,
  });
}

export function bigWin() {
  const end = Date.now() + 1400;
  const frame = () => {
    confetti({ particleCount: 4, angle: 60, spread: 60, origin: { x: 0, y: 0.7 }, colors: COLORS });
    confetti({ particleCount: 4, angle: 120, spread: 60, origin: { x: 1, y: 0.7 }, colors: COLORS });
    if (Date.now() < end) requestAnimationFrame(frame);
  };
  frame();
  confetti({
    particleCount: 200,
    spread: 120,
    startVelocity: 50,
    origin: { y: 0.6 },
    colors: COLORS,
    scalar: 1.1,
  });
}

export function starPop() {
  confetti({
    particleCount: 40,
    spread: 50,
    startVelocity: 25,
    gravity: 0.6,
    origin: { y: 0.5 },
    colors: ["#fbbf24", "#fde68a", "#fff7ed"],
    shapes: ["star"],
    scalar: 0.9,
  });
}
