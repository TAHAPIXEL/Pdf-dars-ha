import { integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

/** A player competing on the leaderboard. */
export const players = pgTable("players", {
  id: text("id").primaryKey(), // client-generated stable id stored in localStorage
  name: text("name").notNull(),
  xp: integer("xp").notNull().default(0),
  streak: integer("streak").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/** Every quiz / exam attempt for stats. */
export const attempts = pgTable("attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  playerId: text("player_id"),
  kind: text("kind").notNull(), // "quiz" | "exam"
  ref: text("ref").notNull(), // lesson slug (e.g. "1-2") or chapter slug (e.g. "ch3")
  correct: integer("correct").notNull(),
  total: integer("total").notNull(),
  score20: integer("score20").notNull(), // grade out of 20
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Player = typeof players.$inferSelect;
export type Attempt = typeof attempts.$inferSelect;
