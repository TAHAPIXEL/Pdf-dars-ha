import { ch1 } from "./ch1";
import { ch2 } from "./ch2";
import { ch3 } from "./ch3";
import { ch4 } from "./ch4";
import { ch5 } from "./ch5";
import { ch6 } from "./ch6";
import { ch7 } from "./ch7";
import { ch8 } from "./ch8";
import { ch9 } from "./ch9";
import type { Chapter, Lesson } from "./types";

export const chapters: Chapter[] = [ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9];

export const totalLessons = chapters.reduce((s, c) => s + c.lessons.length, 0);
export const totalQuestions =
  chapters.reduce((s, c) => s + c.lessons.reduce((a, l) => a + l.quiz.length, 0) + c.exam.length, 0);

export function getChapter(slug: string): Chapter | undefined {
  return chapters.find((c) => c.slug === slug);
}

export function getLesson(chapterSlug: string, lessonSlug: string):
  | { chapter: Chapter; lesson: Lesson; index: number; prev: Lesson | null; next: Lesson | null }
  | undefined {
  const chapter = getChapter(chapterSlug);
  if (!chapter) return undefined;
  const index = chapter.lessons.findIndex((l) => l.slug === lessonSlug);
  if (index === -1) return undefined;
  return {
    chapter,
    lesson: chapter.lessons[index],
    index,
    prev: index > 0 ? chapter.lessons[index - 1] : null,
    next: index < chapter.lessons.length - 1 ? chapter.lessons[index + 1] : null,
  };
}

export type { Chapter, Lesson, QuizQ, LessonSection } from "./types";
