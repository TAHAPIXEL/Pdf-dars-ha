export interface LessonSection {
  heading: string;
  body: string; // Persian text; inline math wrapped in backticks
  example?: {
    problem: string;
    steps: string[]; // revealed one-by-one in the UI
    answer: string;
  };
}

export interface QuizQ {
  q: string;
  options: string[]; // exactly 4
  answer: number; // index of correct option
  explain: string;
}

export interface Lesson {
  slug: string; // "1-1"
  title: string;
  intro: string;
  sections: LessonSection[];
  tip: string;
  quiz: QuizQ[];
}

export interface Chapter {
  id: number;
  slug: string; // url slug
  title: string;
  subtitle: string;
  color: string; // hex accent
  icon: "shapes" | "infinity" | "compass" | "zap" | "braces" | "trending" | "divide" | "box" | "chart";
  outcomes: string[];
  lessons: Lesson[];
  exam: QuizQ[];
}
