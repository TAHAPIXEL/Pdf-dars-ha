"use client";

/**
 * Tiny synthesized sound engine built on the Web Audio API.
 * No audio files needed - everything is generated on the fly.
 */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;

export function setSoundMuted(m: boolean) {
  muted = m;
}

function audio(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.16;
      master.connect(ctx.destination);
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

interface ToneOpts {
  f: number; // frequency
  d?: number; // duration sec
  t?: OscillatorType;
  v?: number; // volume 0..1
  at?: number; // start offset sec
  slide?: number; // slide to freq
}

function tone({ f, d = 0.12, t = "sine", v = 1, at = 0, slide }: ToneOpts) {
  const c = audio();
  if (!c || !master || muted) return;
  const osc = c.createOscillator();
  const g = c.createGain();
  const start = c.currentTime + at;
  osc.type = t;
  osc.frequency.setValueAtTime(f, start);
  if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(30, slide), start + d);
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(v, start + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, start + d);
  osc.connect(g);
  g.connect(master);
  osc.start(start);
  osc.stop(start + d + 0.05);
}

function noise(at: number, d: number, from: number, to: number, v = 0.5) {
  const c = audio();
  if (!c || !master || muted) return;
  const len = Math.floor(c.sampleRate * d);
  const buffer = c.createBuffer(1, len, c.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = c.createBufferSource();
  src.buffer = buffer;
  const bp = c.createBiquadFilter();
  bp.type = "bandpass";
  const start = c.currentTime + at;
  bp.frequency.setValueAtTime(from, start);
  bp.frequency.exponentialRampToValueAtTime(to, start + d);
  const g = c.createGain();
  g.gain.setValueAtTime(v, start);
  g.gain.exponentialRampToValueAtTime(0.0001, start + d);
  src.connect(bp);
  bp.connect(g);
  g.connect(master);
  src.start(start);
}

const NOTES = { c: 523.25, d: 587.33, e: 659.25, f: 698.46, g: 783.99, a: 880, b: 987.77, c2: 1046.5, e2: 1318.5, g2: 1568 };

export const sfx = {
  click() {
    tone({ f: 620, d: 0.07, t: "triangle", v: 0.7 });
    tone({ f: 940, d: 0.05, t: "sine", v: 0.35, at: 0.01 });
  },
  hover() {
    tone({ f: 340, d: 0.04, t: "sine", v: 0.25 });
  },
  pop() {
    tone({ f: 300, d: 0.09, t: "square", v: 0.45, slide: 700 });
  },
  correct() {
    tone({ f: NOTES.e, d: 0.12, t: "triangle", v: 0.8 });
    tone({ f: NOTES.g, d: 0.12, t: "triangle", v: 0.8, at: 0.09 });
    tone({ f: NOTES.c2, d: 0.22, t: "triangle", v: 0.9, at: 0.18 });
  },
  wrong() {
    tone({ f: 220, d: 0.2, t: "sawtooth", v: 0.5, slide: 110 });
    tone({ f: 155, d: 0.24, t: "square", v: 0.3, at: 0.05, slide: 90 });
  },
  star() {
    tone({ f: NOTES.c2, d: 0.3, t: "sine", v: 0.8 });
    tone({ f: NOTES.g2, d: 0.4, t: "sine", v: 0.5, at: 0.08 });
  },
  coin() {
    tone({ f: NOTES.b, d: 0.08, t: "square", v: 0.5 });
    tone({ f: NOTES.e2, d: 0.3, t: "square", v: 0.5, at: 0.08 });
  },
  levelup() {
    const seq = [NOTES.c, NOTES.e, NOTES.g, NOTES.c2, NOTES.e2, NOTES.g2];
    seq.forEach((f, i) => tone({ f, d: 0.16, t: "triangle", v: 0.75, at: i * 0.09 }));
    noise(0.1, 0.5, 800, 4000, 0.15);
  },
  win() {
    const seq = [NOTES.g, NOTES.c2, NOTES.e2, NOTES.g2];
    seq.forEach((f, i) => tone({ f, d: 0.2, t: "triangle", v: 0.7, at: i * 0.11 }));
    tone({ f: NOTES.c2, d: 0.5, t: "sine", v: 0.4, at: 0.44 });
    noise(0.05, 0.6, 600, 5000, 0.12);
  },
  lose() {
    [392, 330, 262, 196].forEach((f, i) => tone({ f, d: 0.22, t: "triangle", v: 0.55, at: i * 0.16 }));
  },
  whoosh() {
    noise(0, 0.28, 300, 2600, 0.35);
  },
  unlock() {
    tone({ f: 500, d: 0.1, t: "triangle", v: 0.6 });
    tone({ f: 750, d: 0.14, t: "triangle", v: 0.6, at: 0.09 });
    tone({ f: 1000, d: 0.2, t: "sine", v: 0.6, at: 0.18 });
  },
  tick() {
    tone({ f: 880, d: 0.05, t: "square", v: 0.3 });
  },
};
