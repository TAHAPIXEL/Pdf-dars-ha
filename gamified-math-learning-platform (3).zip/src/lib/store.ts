"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { setSoundMuted } from "@/lib/sounds";
import { todayKey, uid, yesterdayKey } from "@/lib/utils";

export interface QuizResult {
  correct: number;
  total: number;
  stars: number; // 0..3
  score20: number; // Iranian school grade out of 20
  at: number; // timestamp
}

interface GameState {
  playerId: string | null;
  playerName: string;
  xp: number;
  streak: number;
  lastActive: string | null;
  muted: boolean;
  hearts: number;
  completedLessons: string[]; // lesson slugs fully passed
  lessonResults: Record<string, QuizResult>;
  examResults: Record<string, QuizResult>;
  // actions
  setPlayer: (name: string) => void;
  toggleMuted: () => void;
  loseHeart: () => void;
  refillHearts: () => void;
  addXp: (n: number) => void;
  touchStreak: () => void;
  recordLesson: (slug: string, r: Omit<QuizResult, "at">) => void;
  recordExam: (chapterId: string, r: Omit<QuizResult, "at">) => void;
  resetAll: () => void;
}

export const XP_PER_LEVEL = 150;
export const MAX_HEARTS = 3;

export function levelFor(xp: number) {
  const level = Math.floor(xp / XP_PER_LEVEL) + 1;
  const into = xp % XP_PER_LEVEL;
  return { level, into, pct: Math.round((into / XP_PER_LEVEL) * 100) };
}

export function starsFor(correct: number, total: number): number {
  const p = total === 0 ? 0 : correct / total;
  if (correct === total) return 3;
  if (p >= 0.7) return 2;
  if (p >= 0.4) return 1;
  return 0;
}

function syncPlayer(get: () => GameState) {
  const s = get();
  if (!s.playerId) return;
  fetch("/api/players", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: s.playerId, name: s.playerName, xp: s.xp, streak: s.streak }),
  }).catch(() => undefined);
}

function syncAttempt(kind: "quiz" | "exam", ref: string, r: { correct: number; total: number; score20: number }, playerId: string | null) {
  fetch("/api/attempts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ kind, ref, correct: r.correct, total: r.total, score20: r.score20, playerId }),
  }).catch(() => undefined);
}

export const useGame = create<GameState>()(
  persist(
    (set, get) => ({
      playerId: null,
      playerName: "",
      xp: 0,
      streak: 0,
      lastActive: null,
      muted: false,
      hearts: MAX_HEARTS,
      completedLessons: [],
      lessonResults: {},
      examResults: {},

      setPlayer: (name) => {
        const id = get().playerId ?? uid();
        set({ playerId: id, playerName: name });
        syncPlayer(get);
      },

      toggleMuted: () => {
        const m = !get().muted;
        setSoundMuted(m);
        set({ muted: m });
      },

      loseHeart: () => set({ hearts: Math.max(0, get().hearts - 1) }),
      refillHearts: () => set({ hearts: MAX_HEARTS }),

      addXp: (n) => {
        set({ xp: get().xp + n });
        syncPlayer(get);
      },

      touchStreak: () => {
        const today = todayKey();
        const s = get();
        if (s.lastActive === today) return;
        const streak = s.lastActive === yesterdayKey() ? s.streak + 1 : 1;
        set({ lastActive: today, streak, hearts: MAX_HEARTS });
        syncPlayer(get);
      },

      recordLesson: (slug, r) => {
        const prev = get().lessonResults[slug];
        const better = !prev || r.correct > prev.correct || r.correct === r.total;
        const gainedXp = better ? r.correct * 10 + (r.correct === r.total ? 20 : 0) + 25 : r.correct * 2;
        const completed = new Set(get().completedLessons);
        completed.add(slug);
        set({
          lessonResults: { ...get().lessonResults, [slug]: better ? { ...r, at: Date.now() } : prev },
          completedLessons: Array.from(completed),
          xp: get().xp + gainedXp,
        });
        get().touchStreak();
        syncAttempt("quiz", slug, r, get().playerId);
        syncPlayer(get);
      },

      recordExam: (chapterId, r) => {
        const prev = get().examResults[chapterId];
        const better = !prev || r.score20 > prev.score20;
        const gainedXp = better ? r.score20 + (r.score20 >= 17 ? 30 : 0) + 40 : Math.round(r.score20 / 2);
        set({
          examResults: { ...get().examResults, [chapterId]: better ? { ...r, at: Date.now() } : prev },
          xp: get().xp + gainedXp,
        });
        get().touchStreak();
        syncAttempt("exam", chapterId, r, get().playerId);
        syncPlayer(get);
      },

      resetAll: () =>
        set({
          xp: 0,
          streak: 0,
          lastActive: null,
          hearts: MAX_HEARTS,
          completedLessons: [],
          lessonResults: {},
          examResults: {},
        }),
    }),
    {
      name: "riazi9-quest",
      onRehydrateStorage: () => (state) => {
        if (state?.muted) setSoundMuted(true);
      },
    }
  )
);
